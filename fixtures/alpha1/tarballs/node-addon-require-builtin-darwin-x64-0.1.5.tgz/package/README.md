# node-addon-require-builtin-darwin-x64

Optional prebuilt native addon package for `darwin-x64`.

The main `node-addon-require-builtin` package selects one binary from
this package at runtime using `prebuilds.json`.
