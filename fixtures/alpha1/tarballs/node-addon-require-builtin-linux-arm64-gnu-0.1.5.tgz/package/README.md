# node-addon-require-builtin-linux-arm64-gnu

Optional prebuilt native addon package for `linux-arm64-gnu`.

The main `node-addon-require-builtin` package selects one binary from
this package at runtime using `prebuilds.json`.
