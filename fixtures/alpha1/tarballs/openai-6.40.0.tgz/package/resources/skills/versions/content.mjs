// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../../../core/resource.mjs";
import { buildHeaders } from "../../../internal/headers.mjs";
import { path } from "../../../internal/utils/path.mjs";
export class Content extends APIResource {
    /**
     * Download a skill version zip bundle.
     */
    retrieve(version, params, options) {
        const { skill_id } = params;
        return this._client.get(path `/skills/${skill_id}/versions/${version}/content`, {
            ...options,
            headers: buildHeaders([{ Accept: 'application/binary' }, options?.headers]),
            __security: { bearerAuth: true },
            __binaryResponse: true,
        });
    }
}
//# sourceMappingURL=content.mjs.map